#!/bin/bash
chmod 400 nickKey_Oregon.pem
ssh -i nickKey_Oregon.pem bitnami@34.210.204.122
